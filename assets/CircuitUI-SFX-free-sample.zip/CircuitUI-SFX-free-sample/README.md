# Circuit UI SFX Vol. 1

148 procedural retro/arcade sound effects for game jams, prototypes, pixel-art games, and 8-bit/chiptune-style projects.

## Contents

- 148 WAV files, 44.1 kHz / 16-bit
- Matching OGG and MP3 versions
- `metadata.csv` with filenames, categories, durations, and descriptions
- `preview/circuit-ui-preview.mp3` and `.wav`
- `cover.png`

## Categories

- UI clicks, hovers, backs, confirms, errors, toggles
- Typewriter ticks
- Coins, pickups, powerups
- Jumps, landings, hits
- Lasers, explosions, whooshes, alarms
- Success, fail, and secret stingers

## Validation

Generated deterministically with `generate.py`, normalized without intentional clipping, encoded with ffmpeg, and checked for playable WAV/OGG/MP3 output. These are clean procedural retro effects, not recorded foley or realistic cinematic sounds.

## License

See `LICENSE.txt`.
